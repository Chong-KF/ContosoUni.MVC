﻿using ContosoUni.Areas.Identity.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSUnitTestForDepartmentViews
{
    public class UserManagerMocker : UserManager<MyIdentityUser>
    {
        public UserManagerMocker()
            : base(new Mock<IUserStore<MyIdentityUser>>().Object,
                  new Mock<IOptions<IdentityOptions>>().Object,
                  new Mock<IPasswordHasher<MyIdentityUser>>().Object,
                  new IUserValidator<MyIdentityUser>[0],
                  new IPasswordValidator<MyIdentityUser>[0],
                  new Mock<ILookupNormalizer>().Object,
                  new Mock<IdentityErrorDescriber>().Object,
                  new Mock<IServiceProvider>().Object,
                  new Mock<ILogger<UserManager<MyIdentityUser>>>().Object)
        { }

    }
}
