using Microsoft.VisualStudio.TestTools.UnitTesting;

using Moq;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Identity;
using ContosoUni.Areas.Identity.Models;
using ContosoUni.Controllers;
using ContosoUni.Services;
using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.TestHost;
using Microsoft.AspNetCore.Hosting;
using System.Net.Http;
using System.Net;
using System.Linq;
using ContosoUni.Data;
using Microsoft.AspNetCore.Http;

namespace MSUnitTestForDepartmentViews
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public async Task CheckIfIndexReturnView()
        {
            // 1. Arrange
            // create a mock for logger            
            var mockLogger = Mock.Of<ILogger<DepartmentsController>>();
            var mockUserManager = Mock.Of<UserManagerMocker>();
            var mockSignInManager = Mock.Of<SignInManagerMocker>();
            var mockAzureQueue = Mock.Of<IAzureQueue>();
            using var mockDbContext = DbContextMocker.GetApplicationDBContext("Testdb"); 
            // create an instance of the controller
            var controller = new DepartmentsController(mockDbContext, mockUserManager, mockLogger, mockAzureQueue);

            var password = "W7TzX6ZJjUQ-X74";
            var adminUser = new MyIdentityUser
            {
                UserName = "admin@gmail.com",
                DisplayName = "Admin",
                Email = "admin@gmail.com",
                EmailConfirmed = true,
                //PhoneNumberConfirmed = true,
                IsActive = true
            };
            if (mockUserManager.Users.All(u => u.Id != adminUser.Id))
            {
                MyIdentityUser user = await mockUserManager.FindByEmailAsync(adminUser.Email);
                if (user == null)
                {
                    await mockUserManager.CreateAsync(adminUser, password);
                    await mockUserManager.AddToRoleAsync(adminUser, MyRoles.Administrator.ToString());
                    await mockUserManager.AddToRoleAsync(adminUser, MyRoles.Staff.ToString());
                }
            }

            var result = await mockSignInManager.PasswordSignInAsync(adminUser.Email, password, false, lockoutOnFailure: false);
            //if (result.Succeeded)
            //{ }

            // 2. Act
            var action = controller.Index(false);
            
            // 3. Assert
            // Check if the result of the action is a View
            Assert.IsInstanceOfType(action.Result, typeof(ViewResult));
            Console.WriteLine("(a) Check the result of Index");

            // 2. Act
            action = controller.Details(Guid.Parse("40204a97-831a-43f5-b096-c8711f620990"));

            // 3. Assert
            // Check if the result of the action is a View
            Assert.IsInstanceOfType(action.Result, typeof(ViewResult));
            Console.WriteLine("(b) Check the result of Details");
        }
    }
}
