﻿using ContosoUni.Areas.Identity.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSUnitTestForDepartmentViews
{
    public class SignInManagerMocker : SignInManager<MyIdentityUser>
    {
        public SignInManagerMocker()
            : base(new UserManagerMocker(),
                  new Mock<IHttpContextAccessor>().Object,
                  new Mock<IUserClaimsPrincipalFactory<MyIdentityUser>>().Object,
                  new Mock<IOptions<IdentityOptions>>().Object,
                  new Mock<ILogger<SignInManager<MyIdentityUser>>>().Object,
                  new Mock<IAuthenticationSchemeProvider>().Object,
                  new Mock<IUserConfirmation<MyIdentityUser>>().Object
                  )
        { }

        //#region Public methods
        //public override Task<SignInResult> PasswordSignInAsync(MyIdentityUser user, string password, bool isPersistent, bool lockoutOnFailure)
        //{
        //    return Task.FromResult(SignInResult.Success);
        //}

        //public override Task<SignInResult> PasswordSignInAsync(string userName, string password, bool isPersistent, bool lockoutOnFailure)
        //{
        //    return Task.FromResult(SignInResult.Success);
        //}

        //public override Task<SignInResult> CheckPasswordSignInAsync(MyIdentityUser user, string password, bool lockoutOnFailure)
        //{
        //    return Task.FromResult(SignInResult.Success);
        //}
        //#endregion
    }
}
