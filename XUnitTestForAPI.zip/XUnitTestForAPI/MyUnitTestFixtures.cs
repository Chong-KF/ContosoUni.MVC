﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Microsoft.Extensions.Logging;
using ContosoUni.Controllers;
using ContosoUni.Data;
using Moq;

namespace XUnitTestForAPI
{
    public class MyUnitTestFixtures : IDisposable
    {
        public ILogger<DepartmentsApiController> _mockLogger;
        public ApplicationDbContext _mockDbContext;
        public DepartmentsApiController _mockController;
       
        public MyUnitTestFixtures()
        {
            // 1. Arrange
            // Define the "Fixtures" (i.e., commonly shared objects for each of the tests)
            _mockLogger = Mock.Of<ILogger<DepartmentsApiController>>();
            _mockDbContext = DbContextMocker.GetApplicationDBContext("Testdb");
            _mockController = new DepartmentsApiController(_mockLogger, _mockDbContext);
            //this.controller = new DepartmentsApiController(context: mockDbContext, logger: mockLogger);
        }

        #region System.IDisposable menbers
        public void Dispose()
        {
            // Since the in-memory datacontext is no longer needed, dispose of it.
            _mockDbContext.Dispose();
        }
        #endregion
    }
}
