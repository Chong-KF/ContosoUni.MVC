using ContosoUni.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using Xunit.Abstractions;

namespace XUnitTestForAPI
{
    public class UnitTest1 : IClassFixture<MyUnitTestFixtures>
    {
        private MyUnitTestFixtures _fixtures;
        private readonly ITestOutputHelper _testOutputHelper;

        public UnitTest1(
            MyUnitTestFixtures fixtures,
            ITestOutputHelper testOutputHelper
            )
        {
            _fixtures = fixtures;
            _testOutputHelper = testOutputHelper;
        }

        

        [Fact]
        public async Task TestDepartmentGetAll()
        {
            // 1.Arrange
            var logger = _fixtures._mockLogger;
            var dbContext = _fixtures._mockDbContext;
            var controller = _fixtures._mockController;
            int totalrecords = 3;
            // 2. Act
            var actionResuit = await controller.GetDepartments();
            var departments = actionResuit.Value;

            // 3. Assert - check if API action methof returned any data
            Assert.NotNull(departments);
            
            // 3. Assert - check if number of departments is as per the seeded data
            int numberofDepartments = (departments as IList<Department>).Count;
            Assert.Equal(totalrecords, numberofDepartments);
            _testOutputHelper.WriteLine($"expect = {totalrecords}, actual = {numberofDepartments}");
            foreach (Department dept in departments)
            {
                _testOutputHelper.WriteLine($"{dept.DepartmentID}, {dept.DepartmentName}");
            }
            _testOutputHelper.WriteLine("TestDepartmentGetAll Pass");
        }

        [Fact]
        public async Task TestDepartmentGetSingle()
        {
            // 1.Arrange
            var logger = _fixtures._mockLogger;
            var dbContext = _fixtures._mockDbContext;
            var controller = _fixtures._mockController;

            // 2. Act
            var id = Guid.Parse("40d4d4f1-130b-4e6a-bfc6-dfd609fd3e26");
            var actionResuit = await controller.GetDepartment(id);
            Department department = actionResuit.Value;
            var check = "Science Department";

            // 3. Assert - check if API action methof returned any data
            Assert.NotNull(department);

            // 3. Assert - check if data is the same as what was seeded in the inmerory database
            Assert.Equal(id, department.DepartmentID);
            Assert.Equal(check, department.DepartmentName);
            _testOutputHelper.WriteLine($"Requested id: {id}");
            _testOutputHelper.WriteLine($"DepartmentID: {department.DepartmentID}");
            _testOutputHelper.WriteLine($"Check name: {check}");
            _testOutputHelper.WriteLine($"DepartmentName: {department.DepartmentName}");
            _testOutputHelper.WriteLine("TestDepartmentGetSingle Pass");
        }

        [Fact]
        public async Task TestDepartmentPost()
        {
            // 1.Arrange
            var logger = _fixtures._mockLogger;
            var dbContext = _fixtures._mockDbContext;
            var controller = _fixtures._mockController;
            Guid id = Guid.NewGuid();
            Guid user = Guid.NewGuid();
            Department deptToAdd = new Department
            {
                DepartmentID = id,
                DepartmentName = "Arts Department",
                CreatedByUserId = user,
                LastUpdatedOn = DateTime.Now,
                IsDeleted = false
            };

            // 2. Act
            var actionResuit = await controller.GetDepartments();
            var departments = actionResuit.Value;
            _testOutputHelper.WriteLine($"departments before POST: {(departments as IList<Department>).Count}");

            var action = await controller.PostDepartment(deptToAdd);
            var actionResult = action.Result as CreatedAtActionResult;

            // 3. Assert - check if OkObjectResult is obtained.
            Assert.NotNull(actionResult);

            // 3. Assert - check if the Department was added successfully to the inmemory datacontext
            Department deptAdded = actionResult.Value as Department;
            Assert.NotNull(deptAdded);

            // 3. Assert - check if the object added matches with the object intended to be added
            Assert.Equal(deptToAdd.DepartmentName, deptAdded.DepartmentName);

            // this would fail in actual DB, cos id is auto increment
            Assert.Equal(deptToAdd.DepartmentID, deptAdded.DepartmentID);

            actionResuit = await controller.GetDepartments();
            departments = actionResuit.Value;
            _testOutputHelper.WriteLine($"departments after POST: {(departments as IList<Department>).Count}");

            _testOutputHelper.WriteLine("TestDepartmentPost Pass");
        }

        [Fact]
        public async Task TestDepartmentPut()
        {
            // 1.Arrange
            var logger = _fixtures._mockLogger;
            var dbContext = _fixtures._mockDbContext;
            var controller = _fixtures._mockController;

            // 2. Act
            var id = Guid.Parse("ace4c376-7cb9-429a-9c59-4e765bbd5f0e");
            var actionResuit = await controller.GetDepartment(id);
            Department department = actionResuit.Value;

            _testOutputHelper.WriteLine($"Requested id: {id}");
            _testOutputHelper.WriteLine($"DepartmentID: {department.DepartmentID}");
            _testOutputHelper.WriteLine($"DepartmentName before PUT: {department.DepartmentName}");

            string temp = "Test Department";
            department.DepartmentName = temp;
            var actionResult = await controller.PutDepartment(id, department);

            // 3. Assert - check if OkObjectResult is obtained.
            Assert.NotNull(actionResult);

            // 3. Assert - check if the object edit matches with the object intended to be added
            actionResuit = await controller.GetDepartment(id);
            department = actionResuit.Value;
            _testOutputHelper.WriteLine($"Modify name: {temp}");
            _testOutputHelper.WriteLine($"DepartmentName after PUT: {department.DepartmentName}");
            _testOutputHelper.WriteLine("TestDepartmentPut Pass");
        }

        [Fact]
        public async Task TestDepartmentDelete()
        {
            // 1.Arrange
            var logger = _fixtures._mockLogger;
            var dbContext = _fixtures._mockDbContext;
            var controller = _fixtures._mockController;

            // 2. Act
            var tempResuit = await controller.GetDepartments();
            var departments = tempResuit.Value;
            _testOutputHelper.WriteLine($"departments before DELETE: {(departments as IList<Department>).Count}");


            var id = Guid.Parse("ace4c376-7cb9-429a-9c59-4e765bbd5f0e");
            var actionResuit = await controller.GetDepartment(id);
            Department department = actionResuit.Value;

            department.IsDeleted = true;

            var actionResult = await controller.DeleteDepartment(id);

            // 3. Assert - check if OkObjectResult is obtained.
            Assert.NotNull(actionResult);

            // 3. Assert - check if the object edit matches with the object intended to be added
            actionResuit = await controller.GetDepartment(id);
            department = actionResuit.Value;
            Assert.NotNull(actionResult);


            tempResuit = await controller.GetDepartments();
            departments = tempResuit.Value;
            _testOutputHelper.WriteLine($"departments after DELETE: {(departments as IList<Department>).Count}");

            _testOutputHelper.WriteLine("TestDepartmentPut Pass");
        }
    }
}
